# Design System Document: Editorial Civic Participations

## 1. Overview & Creative North Star
**The Creative North Star: "The Modern Muralist"**

This design system rejects the "government portal" archetype of cluttered grids and bureaucratic coldness. Instead, it draws inspiration from Mexican Modernism and Muralism—characterized by bold storytelling, monumental scale, and human-centric narratives. 

We achieve a "High-End Editorial" feel by treating the interface as a digital canvas. We move away from the "standard" UI through intentional asymmetry, massive typographic contrast, and layered depth. The experience must feel like a premium publication: authoritative yet deeply accessible. We prioritize "Breathing Room" over density, ensuring that every civic action feels significant and every piece of data feels transparent.

---

## 2. Colors & Surface Philosophy
The palette balances the authoritative weight of `primary` blue with the vibrant, civic energy of `secondary` magenta and `tertiary` gold.

### The "No-Line" Rule
**Explicit Instruction:** Traditional 1px solid borders are strictly prohibited for sectioning or containment. Boundaries must be defined through background color shifts or tonal transitions.
- **Example:** A project feed should live on `surface-container-low`, while the individual project cards transition to `surface-container-lowest` (pure white) to create a "lift" without a stroke.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. Use the following tiers to define importance:
- **Base Layer:** `surface` (#faf9f9) for the overall page background.
- **Sectional Layer:** `surface-container-low` (#f5f3f3) to group related content blocks.
- **Interactive Layer:** `surface-container-lowest` (#ffffff) for cards, inputs, and primary interactive containers.
- **Prominent Layer:** `surface-container-high` (#e9e8e8) for sidebars or navigation elements that need to feel "closer" to the user.

### The "Glass & Gradient" Rule
To escape the "flat" look, utilize `surface-tint` gradients. For Hero sections or primary CTAs, use a subtle linear gradient transitioning from `primary` (#005c7e) to `primary-container` (#0b769f). Floating navigation menus should utilize a **Glassmorphism** effect: `surface` color at 80% opacity with a `24px` backdrop-blur.

---

## 3. Typography
We use a dual-font strategy to balance character with extreme legibility.

- **Display & Headline (Plus Jakarta Sans):** Our "Voice." This font is modern, geometric, and friendly. We use `display-lg` (3.5rem) for major civic calls to action to create a sense of monumental importance.
- **Title, Body, & Labels (Public Sans):** Our "Clarity." Public Sans is a neutral, highly readable typeface designed for government interfaces. It ensures that even at `body-sm`, the text remains legible for users with varying visual abilities.

**Editorial Tip:** Use `headline-lg` in `primary` blue for section titles, paired with `body-lg` in `on-surface-variant` for descriptions. This high-contrast pairing mimics high-end editorial layouts.

---

## 4. Elevation & Depth
In this system, depth is a tool for clarity, not just decoration.

- **The Layering Principle:** Avoid shadows where background color shifts can do the work. A `surface-container-lowest` card on a `surface-container-low` background provides enough "natural lift."
- **Ambient Shadows:** For "floating" elements like Modals or Floating Action Buttons (FABs), use extra-diffused shadows.
  - *Specs:* Blur: 32px, Y-Offset: 8px, Color: `on-surface` (#1b1c1c) at 6% opacity.
- **The "Ghost Border" Fallback:** If a border is required for high-contrast accessibility (WCAG), use `outline-variant` (#bfc8cf) at 15% opacity. Never use 100% opaque borders.
- **Cultural Texture:** Subtle Mexican textile patterns (Oaxacan or Otomí geometries) should be applied as a low-opacity mask (3%–5%) on `surface-container` backgrounds or inside the `primary-container` gradients. They should be felt, not seen.

---

## 5. Components

### Buttons
- **Primary:** `primary` background, `on-primary` text. Use `rounded-md` (0.375rem). For a premium feel, add a 2px bottom "weighted" shadow rather than a full glow.
- **Action (Voting):** Use `secondary` (#b40067) or `tertiary` (#745b00) to distinguish civic actions from navigation.
- **Labels:** Every button must include a text label. Icons are never standalone.

### Cards & Projects
- **The Rule:** No dividers. Use `spacing-6` (2rem) between content blocks within the card.
- **Visuals:** Project cards should feature a large `primary-fixed` header area. Subtle textile motifs appear only on the "Featured" cards to draw the eye.

### Civic Voting Interface
- **The "Secure" Look:** Use `surface-container-highest` for the voting track. The "Selected" state should use a thick 4px "Ghost Border" of `primary` to feel locked-in and authoritative.
- **Success States:** Use `3A7C22` (Success) only after a vote is cast, accompanied by a full-screen "confirmation" layer using Glassmorphism.

### Input Fields
- **Interaction:** On focus, the background shifts from `surface-container-low` to `surface-container-lowest`. The label moves to a `label-sm` position using `primary` color.
- **Support:** Every input must have `body-sm` helper text visible by default to assist low-literacy users.

---

## 6. Do’s and Don’ts

### Do
- **Do** use `spacing-16` or `spacing-20` for top-level section margins to create an "Editorial" feel.
- **Do** overlap images or cards slightly over section boundaries to break the "grid" and create a custom, high-end look.
- **Do** use `on-surface-variant` for secondary text to maintain a soft, sophisticated hierarchy.

### Don’t
- **Don't** use black (#000000) for text. Always use `on-surface` (#1b1c1c).
- **Don't** use standard "drop shadows." Use tonal layering (Surface shifts) first.
- **Don't** use icons without labels. This is a hard rule for accessibility and inclusivity.
- **Don't** clutter. If a screen feels full, increase the spacing scale and move content to a secondary "nested" layer.